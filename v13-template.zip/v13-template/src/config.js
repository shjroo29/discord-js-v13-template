module.exports = {
	prefix: '+', //change it if you want
	owner: 'ID_CEO', //change it (important)
	token: 'YOUR_TOKEN', //change it (important)
};
